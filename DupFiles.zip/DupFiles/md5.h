#ifndef H_MD5
#define H_MD5
unsigned char * md5Check(char * path);

#endif