#ifndef H_DUP
#define H_DUP
#include "hashTable.h"
int findRec(char * path,hashtable_t * hash);
int findMyFiles(char * path);

#endif